<?php include("head.php")?>
<div class="border-dark bg-dark d-flex justify-content-around">
    <nav class="navbar navbar-dark navbar-expand-sm bg-dark navbar-dark">
        <div class="mt-3">
            <ul class="nav justify-content-start">  
                <li class="nav-item">
                <a class="navbar-brand active pl-3 pb-3" href="index.php">Accueil</a>
                </li>
                <li class="nav-item">
                <a class="navbar-brand active pl-3 pb-3" href="partie1.php">Partie 1</a>
                </li>
                <li class="nav-item">
                <a class="navbar-brand active pl-3 pb-3" href="partie2.php">Partie 2</a>
                </li>
                <li class="nav-item">
                <a class="navbar-brand active pl-3 pb-3" href="partie3.php">Partie 3</a>
                </li>
                <li class="nav-item">
                <a class="navbar-brand active pl-3 pb-3" href="conclusion.php">Conclusion</a>
                </li>
            </ul>
        </div>
    </nav>
</div>
    
