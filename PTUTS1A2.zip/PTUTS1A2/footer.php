<footer class="page-footer font-small bg-dark pt-4 border-top border-light">
	<div class="container-fluid text-center text-md-left bg-dark">
		<div class="row">
			<div class="col-md-6 mt-md-0 mt-3">
				<h5 class="text-uppercase font-weight-bold text-light">Membres du groupe</h5>
				<p class="text-light pt-3">Sité réalisé par BERNHARD William, HEIDET Lucas, TROGNOT Mathias, VILMARD Alexis, dans le cadre de notre projet tutoré sur les logiciels de musique assistée par ordinateur  à l'IUT Informatique de Belfort </p>
			</div>
			<hr class="clearfix w-100 d-md-none pb-3">
			<div class="col-md-6 mb-md-0 mb-3">
				<h5 class="text-uppercase font-weight-bold text-light">iut informatique de belfort</h5>
				<div class="d-block d-inline"> 
					<img class="float-left w-25 pt-4, rounded" src="iutinfo.png" alt="Photo de l'iut belfort montbéliard">
					<img class=" float-right ml-5 hauteur rounded" src="iut.png" alt="Photo du département Informatique iut belfort">
				</div>
			</div>
		</div>
	<div class="footer-copyright text-center py-3 text-light" style="background-color: #121214; width: 100%;">© 2020 LesLogicielsMao</div>
	</div>
</footer>