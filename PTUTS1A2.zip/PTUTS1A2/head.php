<header>
<div class=" border-bottom border-light bg-dark justify-content-between">
     <nav class="navbar navbar-dark navbar-expand-sm bg-dark navbar-dark">
        <div class="mt-3">
            <ul class="nav justify-content-start">
                <li class="nav-item">
                    <a class="navbar-brand active pl-3 pb-3" href="index.php">Accueil</a>
                </li>
                <li class="nav-item">
                    <a class="navbar-brand active pl-3 pb-3" href="propos.php">A propos</a>
                </li>
                <li class="nav-item">
                    <a class="navbar-brand active pl-3 pb-3" href="mailer.php">Nous contacter</a>
                </li>
            </ul>
        </div>
    </nav>
</div>
</header>
