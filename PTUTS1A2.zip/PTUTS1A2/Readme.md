# Schémas
Les schémas se trouves dans docs/site/Maquettes-navigationdocs/site/Maquettes-navigation

![diag-naviga](docs/site/Diagramme%20de%20navigation.PNG)

# https://maoptut.herokuapp.com/

# Heroku
L'application heroku est gérée depuis https://dashboard.heroku.com/apps/maoptut

 En cas de problème d'accès, m'envoyer un mail à alexis.vilmard@edu.univ-fcomte.fr.
